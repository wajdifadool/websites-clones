# Microsoft Homepage Clone

This was originally a tutorial by Traversy Media. But my version is slightly improved; adding animations and better responsive design. But still, I didn't bother making menus with Javascript.

## Gallery

![Preview 1](preview/preview1.png)
![Preview 2](preview/preview2.png)
![Preview 3](preview/preview3.png)

> I'll keep releasing updates whenever I can.
